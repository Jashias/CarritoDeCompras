﻿namespace CarritoDeCompras
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_registrarse = new Button();
            btn_volver = new Button();
            txt_correo = new Label();
            txt_usuario = new Label();
            txt_contrasena = new Label();
            tb_correo = new TextBox();
            tb_usuario = new TextBox();
            tb_contrasena = new TextBox();
            nav = new Panel();
            txt_titulo = new Label();
            txt_minimizar = new Label();
            txt_close = new Label();
            label1 = new Label();
            nav.SuspendLayout();
            SuspendLayout();
            // 
            // btn_registrarse
            // 
            btn_registrarse.AutoSize = true;
            btn_registrarse.Cursor = Cursors.Hand;
            btn_registrarse.FlatStyle = FlatStyle.Flat;
            btn_registrarse.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            btn_registrarse.ForeColor = Color.White;
            btn_registrarse.Location = new Point(234, 290);
            btn_registrarse.Margin = new Padding(3, 2, 3, 2);
            btn_registrarse.Name = "btn_registrarse";
            btn_registrarse.Size = new Size(104, 29);
            btn_registrarse.TabIndex = 0;
            btn_registrarse.Text = "Registrarse";
            btn_registrarse.UseVisualStyleBackColor = true;
            btn_registrarse.Click += btn_registrarse_Click;
            // 
            // btn_volver
            // 
            btn_volver.AutoSize = true;
            btn_volver.Cursor = Cursors.Hand;
            btn_volver.FlatStyle = FlatStyle.Flat;
            btn_volver.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            btn_volver.ForeColor = Color.White;
            btn_volver.Location = new Point(381, 290);
            btn_volver.Margin = new Padding(3, 2, 3, 2);
            btn_volver.Name = "btn_volver";
            btn_volver.Size = new Size(82, 29);
            btn_volver.TabIndex = 1;
            btn_volver.Text = "Volver";
            btn_volver.UseVisualStyleBackColor = true;
            btn_volver.Click += btn_volver_Click;
            // 
            // txt_correo
            // 
            txt_correo.AutoSize = true;
            txt_correo.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            txt_correo.ForeColor = Color.White;
            txt_correo.Location = new Point(234, 152);
            txt_correo.Name = "txt_correo";
            txt_correo.Size = new Size(62, 17);
            txt_correo.TabIndex = 2;
            txt_correo.Text = "Correo:";
            // 
            // txt_usuario
            // 
            txt_usuario.AutoSize = true;
            txt_usuario.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            txt_usuario.ForeColor = Color.White;
            txt_usuario.Location = new Point(234, 198);
            txt_usuario.Name = "txt_usuario";
            txt_usuario.Size = new Size(69, 17);
            txt_usuario.TabIndex = 3;
            txt_usuario.Text = "Usuario:";
            // 
            // txt_contrasena
            // 
            txt_contrasena.AutoSize = true;
            txt_contrasena.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            txt_contrasena.ForeColor = Color.White;
            txt_contrasena.Location = new Point(234, 241);
            txt_contrasena.Name = "txt_contrasena";
            txt_contrasena.Size = new Size(96, 17);
            txt_contrasena.TabIndex = 4;
            txt_contrasena.Text = "Contraseña:";
            // 
            // tb_correo
            // 
            tb_correo.BorderStyle = BorderStyle.None;
            tb_correo.Cursor = Cursors.IBeam;
            tb_correo.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            tb_correo.Location = new Point(303, 152);
            tb_correo.Margin = new Padding(3, 2, 3, 2);
            tb_correo.Multiline = true;
            tb_correo.Name = "tb_correo";
            tb_correo.Size = new Size(159, 19);
            tb_correo.TabIndex = 5;
            // 
            // tb_usuario
            // 
            tb_usuario.BorderStyle = BorderStyle.None;
            tb_usuario.Cursor = Cursors.IBeam;
            tb_usuario.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            tb_usuario.Location = new Point(310, 198);
            tb_usuario.Margin = new Padding(3, 2, 3, 2);
            tb_usuario.Multiline = true;
            tb_usuario.Name = "tb_usuario";
            tb_usuario.Size = new Size(153, 19);
            tb_usuario.TabIndex = 6;
            // 
            // tb_contrasena
            // 
            tb_contrasena.BorderStyle = BorderStyle.None;
            tb_contrasena.Cursor = Cursors.IBeam;
            tb_contrasena.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            tb_contrasena.Location = new Point(338, 241);
            tb_contrasena.Margin = new Padding(3, 2, 3, 2);
            tb_contrasena.Multiline = true;
            tb_contrasena.Name = "tb_contrasena";
            tb_contrasena.Size = new Size(125, 19);
            tb_contrasena.TabIndex = 7;
            // 
            // nav
            // 
            nav.BackColor = Color.LavenderBlush;
            nav.Controls.Add(txt_titulo);
            nav.Controls.Add(txt_minimizar);
            nav.Controls.Add(txt_close);
            nav.Location = new Point(-1, 0);
            nav.Margin = new Padding(3, 2, 3, 2);
            nav.Name = "nav";
            nav.Size = new Size(686, 26);
            nav.TabIndex = 8;
            // 
            // txt_titulo
            // 
            txt_titulo.AutoSize = true;
            txt_titulo.BackColor = Color.Transparent;
            txt_titulo.Font = new Font("Microsoft Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_titulo.ForeColor = Color.White;
            txt_titulo.Location = new Point(233, 77);
            txt_titulo.Name = "txt_titulo";
            txt_titulo.Size = new Size(191, 31);
            txt_titulo.TabIndex = 12;
            txt_titulo.Text = "Iniciar Sesión";
            // 
            // txt_minimizar
            // 
            txt_minimizar.AutoSize = true;
            txt_minimizar.BackColor = Color.Transparent;
            txt_minimizar.Cursor = Cursors.Hand;
            txt_minimizar.Font = new Font("Microsoft Sans Serif", 16.1999989F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_minimizar.ForeColor = Color.LightPink;
            txt_minimizar.Location = new Point(616, -3);
            txt_minimizar.Name = "txt_minimizar";
            txt_minimizar.Size = new Size(28, 26);
            txt_minimizar.TabIndex = 10;
            txt_minimizar.Text = "--";
            txt_minimizar.Click += txt_minimizar_Click;
            // 
            // txt_close
            // 
            txt_close.AutoSize = true;
            txt_close.BackColor = Color.Transparent;
            txt_close.Cursor = Cursors.Hand;
            txt_close.Font = new Font("Microsoft Sans Serif", 16.1999989F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_close.ForeColor = Color.LightPink;
            txt_close.Location = new Point(654, -3);
            txt_close.Name = "txt_close";
            txt_close.Size = new Size(28, 26);
            txt_close.TabIndex = 11;
            txt_close.Text = "X";
            txt_close.Click += txt_close_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(248, 77);
            label1.Name = "label1";
            label1.Size = new Size(165, 31);
            label1.TabIndex = 9;
            label1.Text = "Registrarse";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightPink;
            ClientSize = new Size(684, 415);
            Controls.Add(label1);
            Controls.Add(nav);
            Controls.Add(tb_contrasena);
            Controls.Add(tb_usuario);
            Controls.Add(tb_correo);
            Controls.Add(txt_contrasena);
            Controls.Add(txt_usuario);
            Controls.Add(txt_correo);
            Controls.Add(btn_volver);
            Controls.Add(btn_registrarse);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registro";
            nav.ResumeLayout(false);
            nav.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_registrarse;
        private Button btn_volver;
        private Label txt_correo;
        private Label txt_usuario;
        private Label txt_contrasena;
        private TextBox tb_correo;
        private TextBox tb_usuario;
        private TextBox tb_contrasena;
        private Panel nav;
        private Label txt_minimizar;
        private Label txt_close;
        private Label txt_titulo;
        private Label label1;
    }
}