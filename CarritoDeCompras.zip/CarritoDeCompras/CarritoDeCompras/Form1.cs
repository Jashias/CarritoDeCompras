using System;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace CarritoDeCompras
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_ingresar_Click(object sender, EventArgs e)
        {
            string connectionString = System.Configuration.ConfigurationManager.
             ConnectionStrings["CarritoDeComprasDB"].ConnectionString;

            string usuario = tb_usuario.Text;
            string contrasena = tb_contrasena.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))

            {
                string query = "SELECT COUNT(1) FROM Usuarios WHERE Nombre " +
                    "= @Usuario AND Contrase�a = @Contrase�a";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Usuario", usuario);
                command.Parameters.AddWithValue("@Contrase�a", contrasena);

                try
                {
                    connection.Open();
                    int count = Convert.ToInt32(command.ExecuteScalar());
                    if (count == 1)
                    {
                        MessageBox.Show("Inicio de sesi�n exitoso.");
                        this.Hide();
                        Form3 form3 = new Form3();
                        form3.Show();
                    }
                    else
                    {
                        MessageBox.Show("Usuario o contrase�a incorrectos.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al iniciar sesi�n: " + ex.Message);
                }
            }
        }

        private void btn_registrarse_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void txt_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txt_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}