﻿namespace CarritoDeCompras
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            nav = new Panel();
            txt_titulo = new Label();
            txt_minimizar = new Label();
            txt_close = new Label();
            label1 = new Label();
            listBoxResumen = new ListBox();
            lblTotal = new Label();
            btnConfirmarCompra = new Button();
            nav.SuspendLayout();
            SuspendLayout();
            // 
            // nav
            // 
            nav.BackColor = Color.LavenderBlush;
            nav.Controls.Add(txt_titulo);
            nav.Controls.Add(txt_minimizar);
            nav.Controls.Add(txt_close);
            nav.Location = new Point(-1, 0);
            nav.Margin = new Padding(3, 2, 3, 2);
            nav.Name = "nav";
            nav.Size = new Size(686, 26);
            nav.TabIndex = 9;
            // 
            // txt_titulo
            // 
            txt_titulo.AutoSize = true;
            txt_titulo.BackColor = Color.Transparent;
            txt_titulo.Font = new Font("Microsoft Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_titulo.ForeColor = Color.White;
            txt_titulo.Location = new Point(233, 77);
            txt_titulo.Name = "txt_titulo";
            txt_titulo.Size = new Size(191, 31);
            txt_titulo.TabIndex = 12;
            txt_titulo.Text = "Iniciar Sesión";
            // 
            // txt_minimizar
            // 
            txt_minimizar.AutoSize = true;
            txt_minimizar.BackColor = Color.Transparent;
            txt_minimizar.Cursor = Cursors.Hand;
            txt_minimizar.Font = new Font("Microsoft Sans Serif", 16.1999989F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_minimizar.ForeColor = Color.LightPink;
            txt_minimizar.Location = new Point(616, -3);
            txt_minimizar.Name = "txt_minimizar";
            txt_minimizar.Size = new Size(28, 26);
            txt_minimizar.TabIndex = 10;
            txt_minimizar.Text = "--";
            txt_minimizar.Click += txt_minimizar_Click;
            // 
            // txt_close
            // 
            txt_close.AutoSize = true;
            txt_close.BackColor = Color.Transparent;
            txt_close.Cursor = Cursors.Hand;
            txt_close.Font = new Font("Microsoft Sans Serif", 16.1999989F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_close.ForeColor = Color.LightPink;
            txt_close.Location = new Point(654, -3);
            txt_close.Name = "txt_close";
            txt_close.Size = new Size(28, 26);
            txt_close.TabIndex = 11;
            txt_close.Text = "X";
            txt_close.Click += txt_close_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(265, 77);
            label1.Name = "label1";
            label1.Size = new Size(103, 31);
            label1.TabIndex = 14;
            label1.Text = "Carrito";
            // 
            // listBoxResumen
            // 
            listBoxResumen.FormattingEnabled = true;
            listBoxResumen.ItemHeight = 15;
            listBoxResumen.Location = new Point(248, 130);
            listBoxResumen.Margin = new Padding(3, 2, 3, 2);
            listBoxResumen.Name = "listBoxResumen";
            listBoxResumen.Size = new Size(176, 139);
            listBoxResumen.TabIndex = 15;
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Location = new Point(281, 278);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(106, 15);
            lblTotal.TabIndex = 16;
            lblTotal.Text = "Total de la Compra";
            // 
            // btnConfirmarCompra
            // 
            btnConfirmarCompra.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnConfirmarCompra.AutoSize = true;
            btnConfirmarCompra.FlatStyle = FlatStyle.Flat;
            btnConfirmarCompra.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            btnConfirmarCompra.ForeColor = Color.White;
            btnConfirmarCompra.Location = new Point(255, 304);
            btnConfirmarCompra.Margin = new Padding(3, 2, 3, 2);
            btnConfirmarCompra.Name = "btnConfirmarCompra";
            btnConfirmarCompra.Size = new Size(158, 29);
            btnConfirmarCompra.TabIndex = 17;
            btnConfirmarCompra.Text = "Confirmar Compra";
            btnConfirmarCompra.UseVisualStyleBackColor = true;
            btnConfirmarCompra.Click += btnConfirmarCompra_Click_1;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightPink;
            ClientSize = new Size(684, 415);
            Controls.Add(btnConfirmarCompra);
            Controls.Add(lblTotal);
            Controls.Add(listBoxResumen);
            Controls.Add(label1);
            Controls.Add(nav);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form4";
            nav.ResumeLayout(false);
            nav.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel nav;
        private Label txt_titulo;
        private Label txt_minimizar;
        private Label txt_close;
        private Label label1;
        private ListBox listBoxResumen;
        private Label lblTotal;
        private Button btnConfirmarCompra;
    }
}