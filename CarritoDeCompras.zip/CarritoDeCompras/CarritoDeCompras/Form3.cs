﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;

namespace CarritoDeCompras
{
    public partial class Form3 : Form
    {
        private Dictionary<CheckBox, Producto> productos = new Dictionary<CheckBox, Producto>();

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            CargarProductos();
        }

        private void CargarProductos()
        {
            List<Producto> listaProductos = new List<Producto>();

            string connectionString = System.Configuration.ConfigurationManager
                .ConnectionStrings["CarritoDeComprasDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT ID, Nombre, Precio FROM Productos", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Producto producto = new Producto
                    {
                        ID = reader.GetInt32(0),
                        Nombre = reader.GetString(1),
                        Precio = reader.GetDecimal(2)
                    };
                    listaProductos.Add(producto);
                }
            }

            if (listaProductos.Count >= 8)
            {
                productos[cb_1] = listaProductos[0];
                productos[cb_2] = listaProductos[1];
                productos[cb_3] = listaProductos[2];
                productos[cb_4] = listaProductos[3];
                productos[cb_5] = listaProductos[4];
                productos[cb_6] = listaProductos[5];
                productos[cb_7] = listaProductos[6];
                productos[cb_8] = listaProductos[7];

                cb_1.Text = $"{listaProductos[0].Nombre} - ${listaProductos[0].Precio}";
                cb_2.Text = $"{listaProductos[1].Nombre} - ${listaProductos[1].Precio}";
                cb_3.Text = $"{listaProductos[2].Nombre} - ${listaProductos[2].Precio}";
                cb_4.Text = $"{listaProductos[3].Nombre} - ${listaProductos[3].Precio}";
                cb_5.Text = $"{listaProductos[4].Nombre} - ${listaProductos[4].Precio}";
                cb_6.Text = $"{listaProductos[5].Nombre} - ${listaProductos[5].Precio}";
                cb_7.Text = $"{listaProductos[6].Nombre} - ${listaProductos[6].Precio}";
                cb_8.Text = $"{listaProductos[7].Nombre} - ${listaProductos[7].Precio}";
            }
            else
            {
                MessageBox.Show("No hay suficientes productos en la base de datos.");
            }
        }

        private void btn_carrito_Click(object sender, EventArgs e)
        {
            List<Producto> productosSeleccionados = new List<Producto>();

            foreach (var item in productos)
            {
                if (item.Key.Checked)
                {
                    productosSeleccionados.Add(item.Value);
                }
            }

            Form4 form4 = new Form4(productosSeleccionados);
            form4.Show();
        }

        private void txt_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void txt_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_cerrar_sesion_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}