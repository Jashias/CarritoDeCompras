﻿namespace CarritoDeCompras
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            nav = new Panel();
            txt_close = new Label();
            txt_minimizar = new Label();
            pb_producto_1 = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            label2 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            btn_carrito = new PictureBox();
            label11 = new Label();
            label13 = new Label();
            label17 = new Label();
            label15 = new Label();
            cb_1 = new CheckBox();
            cb_2 = new CheckBox();
            cb_3 = new CheckBox();
            cb_4 = new CheckBox();
            cb_5 = new CheckBox();
            cb_6 = new CheckBox();
            cb_7 = new CheckBox();
            cb_8 = new CheckBox();
            btn_cerrar_sesion = new Button();
            ((System.ComponentModel.ISupportInitialize)pb_producto_1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btn_carrito).BeginInit();
            SuspendLayout();
            // 
            // nav
            // 
            nav.BackColor = Color.LavenderBlush;
            nav.Location = new Point(-1, 0);
            nav.Margin = new Padding(3, 2, 3, 2);
            nav.Name = "nav";
            nav.Size = new Size(686, 26);
            nav.TabIndex = 7;
            // 
            // txt_close
            // 
            txt_close.AutoSize = true;
            txt_close.BackColor = Color.LavenderBlush;
            txt_close.Cursor = Cursors.Hand;
            txt_close.Font = new Font("Microsoft Sans Serif", 16.1999989F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_close.ForeColor = Color.LightPink;
            txt_close.Location = new Point(654, -4);
            txt_close.Name = "txt_close";
            txt_close.Size = new Size(28, 26);
            txt_close.TabIndex = 9;
            txt_close.Text = "X";
            txt_close.Click += txt_close_Click;
            // 
            // txt_minimizar
            // 
            txt_minimizar.AutoSize = true;
            txt_minimizar.BackColor = Color.LavenderBlush;
            txt_minimizar.Cursor = Cursors.Hand;
            txt_minimizar.Font = new Font("Microsoft Sans Serif", 16.1999989F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txt_minimizar.ForeColor = Color.LightPink;
            txt_minimizar.Location = new Point(616, -3);
            txt_minimizar.Name = "txt_minimizar";
            txt_minimizar.Size = new Size(28, 26);
            txt_minimizar.TabIndex = 10;
            txt_minimizar.Text = "--";
            txt_minimizar.Click += txt_minimizar_Click;
            // 
            // pb_producto_1
            // 
            pb_producto_1.BackColor = Color.Transparent;
            pb_producto_1.Cursor = Cursors.Hand;
            pb_producto_1.Image = (Image)resources.GetObject("pb_producto_1.Image");
            pb_producto_1.Location = new Point(81, 116);
            pb_producto_1.Margin = new Padding(3, 2, 3, 2);
            pb_producto_1.Name = "pb_producto_1";
            pb_producto_1.Size = new Size(70, 60);
            pb_producto_1.SizeMode = PictureBoxSizeMode.Zoom;
            pb_producto_1.TabIndex = 11;
            pb_producto_1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(265, 77);
            label1.Name = "label1";
            label1.Size = new Size(131, 31);
            label1.TabIndex = 13;
            label1.Text = "Catalogo";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(232, 116);
            pictureBox2.Margin = new Padding(3, 2, 3, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(70, 60);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Cursor = Cursors.Hand;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(533, 116);
            pictureBox5.Margin = new Padding(3, 2, 3, 2);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(70, 60);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 17;
            pictureBox5.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.Transparent;
            pictureBox7.Cursor = Cursors.Hand;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(382, 116);
            pictureBox7.Margin = new Padding(3, 2, 3, 2);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(70, 60);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 19;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.Transparent;
            pictureBox8.Cursor = Cursors.Hand;
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(232, 245);
            pictureBox8.Margin = new Padding(3, 2, 3, 2);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(70, 60);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 20;
            pictureBox8.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.Transparent;
            pictureBox11.Cursor = Cursors.Hand;
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(382, 245);
            pictureBox11.Margin = new Padding(3, 2, 3, 2);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(70, 60);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 23;
            pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.Transparent;
            pictureBox12.Cursor = Cursors.Hand;
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(81, 245);
            pictureBox12.Margin = new Padding(3, 2, 3, 2);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(70, 60);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 24;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.Transparent;
            pictureBox13.Cursor = Cursors.Hand;
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(533, 245);
            pictureBox13.Margin = new Padding(3, 2, 3, 2);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(70, 60);
            pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox13.TabIndex = 25;
            pictureBox13.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label2.ForeColor = Color.White;
            label2.Location = new Point(94, 178);
            label2.Name = "label2";
            label2.Size = new Size(44, 17);
            label2.TabIndex = 26;
            label2.Text = "$100";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label4.ForeColor = Color.White;
            label4.Location = new Point(395, 178);
            label4.Name = "label4";
            label4.Size = new Size(44, 17);
            label4.TabIndex = 28;
            label4.Text = "$200";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label6.ForeColor = Color.White;
            label6.Location = new Point(244, 178);
            label6.Name = "label6";
            label6.Size = new Size(44, 17);
            label6.TabIndex = 30;
            label6.Text = "$350";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label7.ForeColor = Color.White;
            label7.Location = new Point(545, 178);
            label7.Name = "label7";
            label7.Size = new Size(44, 17);
            label7.TabIndex = 31;
            label7.Text = "$400";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label8.ForeColor = Color.White;
            label8.Location = new Point(90, 308);
            label8.Name = "label8";
            label8.Size = new Size(0, 17);
            label8.TabIndex = 32;
            // 
            // btn_carrito
            // 
            btn_carrito.BackColor = Color.Transparent;
            btn_carrito.Cursor = Cursors.Hand;
            btn_carrito.Image = (Image)resources.GetObject("btn_carrito.Image");
            btn_carrito.Location = new Point(632, 30);
            btn_carrito.Margin = new Padding(3, 2, 3, 2);
            btn_carrito.Name = "btn_carrito";
            btn_carrito.Size = new Size(40, 30);
            btn_carrito.SizeMode = PictureBoxSizeMode.Zoom;
            btn_carrito.TabIndex = 40;
            btn_carrito.TabStop = false;
            btn_carrito.Click += btn_carrito_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label11.ForeColor = Color.White;
            label11.Location = new Point(95, 308);
            label11.Name = "label11";
            label11.Size = new Size(44, 17);
            label11.TabIndex = 42;
            label11.Text = "$150";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label13.ForeColor = Color.White;
            label13.Location = new Point(247, 308);
            label13.Name = "label13";
            label13.Size = new Size(44, 17);
            label13.TabIndex = 44;
            label13.Text = "$100";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label17.ForeColor = Color.White;
            label17.Location = new Point(545, 308);
            label17.Name = "label17";
            label17.Size = new Size(44, 17);
            label17.TabIndex = 48;
            label17.Text = "$400";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold | FontStyle.Strikeout);
            label15.ForeColor = Color.White;
            label15.Location = new Point(399, 308);
            label15.Name = "label15";
            label15.Size = new Size(44, 17);
            label15.TabIndex = 46;
            label15.Text = "$210";
            // 
            // cb_1
            // 
            cb_1.AutoSize = true;
            cb_1.Location = new Point(81, 202);
            cb_1.Margin = new Padding(3, 2, 3, 2);
            cb_1.Name = "cb_1";
            cb_1.Size = new Size(119, 19);
            cb_1.TabIndex = 49;
            cb_1.Text = "Agregar al Carrito";
            cb_1.UseVisualStyleBackColor = true;
            // 
            // cb_2
            // 
            cb_2.AutoSize = true;
            cb_2.Location = new Point(232, 202);
            cb_2.Margin = new Padding(3, 2, 3, 2);
            cb_2.Name = "cb_2";
            cb_2.Size = new Size(119, 19);
            cb_2.TabIndex = 50;
            cb_2.Text = "Agregar al Carrito";
            cb_2.UseVisualStyleBackColor = true;
            // 
            // cb_3
            // 
            cb_3.AutoSize = true;
            cb_3.Location = new Point(382, 202);
            cb_3.Margin = new Padding(3, 2, 3, 2);
            cb_3.Name = "cb_3";
            cb_3.Size = new Size(119, 19);
            cb_3.TabIndex = 51;
            cb_3.Text = "Agregar al Carrito";
            cb_3.UseVisualStyleBackColor = true;
            // 
            // cb_4
            // 
            cb_4.AutoSize = true;
            cb_4.Location = new Point(533, 202);
            cb_4.Margin = new Padding(3, 2, 3, 2);
            cb_4.Name = "cb_4";
            cb_4.Size = new Size(119, 19);
            cb_4.TabIndex = 52;
            cb_4.Text = "Agregar al Carrito";
            cb_4.UseVisualStyleBackColor = true;
            // 
            // cb_5
            // 
            cb_5.AutoSize = true;
            cb_5.Location = new Point(81, 325);
            cb_5.Margin = new Padding(3, 2, 3, 2);
            cb_5.Name = "cb_5";
            cb_5.Size = new Size(119, 19);
            cb_5.TabIndex = 53;
            cb_5.Text = "Agregar al Carrito";
            cb_5.UseVisualStyleBackColor = true;
            // 
            // cb_6
            // 
            cb_6.AutoSize = true;
            cb_6.Location = new Point(232, 325);
            cb_6.Margin = new Padding(3, 2, 3, 2);
            cb_6.Name = "cb_6";
            cb_6.Size = new Size(119, 19);
            cb_6.TabIndex = 54;
            cb_6.Text = "Agregar al Carrito";
            cb_6.UseVisualStyleBackColor = true;
            // 
            // cb_7
            // 
            cb_7.AutoSize = true;
            cb_7.Location = new Point(382, 325);
            cb_7.Margin = new Padding(3, 2, 3, 2);
            cb_7.Name = "cb_7";
            cb_7.Size = new Size(119, 19);
            cb_7.TabIndex = 55;
            cb_7.Text = "Agregar al Carrito";
            cb_7.UseVisualStyleBackColor = true;
            // 
            // cb_8
            // 
            cb_8.AutoSize = true;
            cb_8.Location = new Point(533, 325);
            cb_8.Margin = new Padding(3, 2, 3, 2);
            cb_8.Name = "cb_8";
            cb_8.Size = new Size(119, 19);
            cb_8.TabIndex = 56;
            cb_8.Text = "Agregar al Carrito";
            cb_8.UseVisualStyleBackColor = true;
            // 
            // btn_cerrar_sesion
            // 
            btn_cerrar_sesion.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btn_cerrar_sesion.AutoSize = true;
            btn_cerrar_sesion.FlatStyle = FlatStyle.Flat;
            btn_cerrar_sesion.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            btn_cerrar_sesion.ForeColor = Color.White;
            btn_cerrar_sesion.Location = new Point(81, 375);
            btn_cerrar_sesion.Margin = new Padding(3, 2, 3, 2);
            btn_cerrar_sesion.Name = "btn_cerrar_sesion";
            btn_cerrar_sesion.Size = new Size(158, 29);
            btn_cerrar_sesion.TabIndex = 57;
            btn_cerrar_sesion.Text = "Cerrar Sesion";
            btn_cerrar_sesion.UseVisualStyleBackColor = true;
            btn_cerrar_sesion.Click += btn_cerrar_sesion_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightPink;
            ClientSize = new Size(684, 415);
            Controls.Add(btn_cerrar_sesion);
            Controls.Add(cb_8);
            Controls.Add(cb_7);
            Controls.Add(cb_6);
            Controls.Add(cb_5);
            Controls.Add(cb_4);
            Controls.Add(cb_3);
            Controls.Add(cb_2);
            Controls.Add(cb_1);
            Controls.Add(label17);
            Controls.Add(label15);
            Controls.Add(label13);
            Controls.Add(label11);
            Controls.Add(btn_carrito);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(pb_producto_1);
            Controls.Add(txt_minimizar);
            Controls.Add(txt_close);
            Controls.Add(nav);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Catalogo";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)pb_producto_1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)btn_carrito).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel nav;
        private Label txt_close;
        private Label txt_minimizar;
        private PictureBox pb_producto_1;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox5;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private Label label2;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private PictureBox btn_carrito;
        private Label label11;
        private Label label13;
        private Label label17;
        private Label label15;
        private CheckBox cb_1;
        private CheckBox cb_2;
        private CheckBox cb_3;
        private CheckBox cb_4;
        private CheckBox cb_5;
        private CheckBox cb_6;
        private CheckBox cb_7;
        private CheckBox cb_8;
        private Button btn_cerrar_sesion;
    }
}