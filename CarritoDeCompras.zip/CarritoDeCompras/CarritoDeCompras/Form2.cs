﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;

namespace CarritoDeCompras
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_registrarse_Click(object sender, EventArgs e)
        {
            string correo = tb_correo.Text;
            string usuario = tb_usuario.Text;
            string contrasena = tb_contrasena.Text;

            if (string.IsNullOrWhiteSpace(correo) || string.IsNullOrWhiteSpace(usuario) 
                || string.IsNullOrWhiteSpace(contrasena))
            {
                MessageBox.Show("Todos los campos son obligatorios.", 
                    "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidEmail(correo))
            {
                MessageBox.Show("Por favor, ingrese una dirección de correo electrónico válida.",
                    "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["CarritoDeComprasDB"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Usuarios (Correo, Nombre, Contraseña) VALUES (@Correo, @Nombre, @Contraseña)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Correo", correo);
                command.Parameters.AddWithValue("@Nombre", usuario);
                command.Parameters.AddWithValue("@Contraseña", contrasena);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Usuario registrado exitosamente.");
                    this.Hide();
                    Form1 form1 = new Form1();
                    form1.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al registrar usuario: " + ex.Message);
                }
            }
        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void txt_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void txt_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}