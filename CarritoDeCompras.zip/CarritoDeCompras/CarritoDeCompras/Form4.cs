﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarritoDeCompras
{
    public partial class Form4 : Form
    {
        private List<Producto> productosSeleccionados;

        public Form4(List<Producto> productos)
        {
            InitializeComponent();
            productosSeleccionados = productos;
            MostrarResumen();
        }

        private void MostrarResumen()
        {
            decimal total = 0;

            foreach (var producto in productosSeleccionados)
            {
                listBoxResumen.Items.Add($"{producto.Nombre} - ${producto.Precio}");
                total += producto.Precio;
            }

            lblTotal.Text = $"Total: ${total}";
        }

        private void GuardarCompra()
        {
            int usuarioID = ObtenerUsuarioID(); 

            string connectionString = System.Configuration.ConfigurationManager
                .ConnectionStrings["CarritoDeComprasDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {

                    SqlCommand cmdCompra = new SqlCommand("INSERT INTO Compras" +
                        " (UsuarioID) OUTPUT INSERTED.ID VALUES (@UsuarioID)", conn, transaction);
                    cmdCompra.Parameters.AddWithValue("@UsuarioID", usuarioID);
                    int compraID = (int)cmdCompra.ExecuteScalar();

                    foreach (var producto in productosSeleccionados)
                    {
                        SqlCommand cmdDetalle = new SqlCommand("INSERT INTO DetallesCompra" +
                            " (CompraID, ProductoID, Cantidad, Precio) VALUES (@CompraID," +
                            " @ProductoID, @Cantidad, @Precio)", conn, transaction);
                        cmdDetalle.Parameters.AddWithValue("@CompraID", compraID);
                        cmdDetalle.Parameters.AddWithValue("@ProductoID", producto.ID);
                        cmdDetalle.Parameters.AddWithValue("@Cantidad", 1); 
                        cmdDetalle.Parameters.AddWithValue("@Precio", producto.Precio);
                        cmdDetalle.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Compra realizada con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Error al realizar la compra: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private int ObtenerUsuarioID()
        {
            return 1; 
        }

        private void txt_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txt_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnConfirmarCompra_Click_1(object sender, EventArgs e)
        {
            GuardarCompra();
            this.Hide(); 
            Form3 form3 = new Form3();
            form3.Show(); 
        }
    }
}